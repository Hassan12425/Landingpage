export const themeList = {
  light: "light",
  dark: "dark",
};
